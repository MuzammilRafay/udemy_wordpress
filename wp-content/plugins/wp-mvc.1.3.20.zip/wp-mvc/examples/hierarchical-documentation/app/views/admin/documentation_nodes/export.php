<h2>Export Documentation</h2>

<p>The button below lets you save the documentation data in a file that can later be imported into the database.</p>

<a href="<?php echo admin_url('/tools.php?page=mvc_documentation_nodes-export&action=mvc_download_documentation_export') ?>" class="button-secondary action">Export</a>