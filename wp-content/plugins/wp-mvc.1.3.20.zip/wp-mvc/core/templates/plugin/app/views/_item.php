<div>
    <?php echo '<?php echo $this->html->'.$name_underscored.'_link($object); ?>'; ?>
</div>