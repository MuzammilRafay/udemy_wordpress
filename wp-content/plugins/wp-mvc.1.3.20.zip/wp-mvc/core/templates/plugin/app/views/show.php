<h2><?php echo '<?php echo $object->__name; ?>'; ?></h2>

<p>
    <?php echo '<?php echo $this->html->link(\'&#8592; All '.$name_titleized_pluralized.'\', array(\'controller\' => \''.$name_tableized.'\')); ?>'; ?>

</p>