<div class="wrap">

<?php $this->display_flash(); ?>

<?php $this->render_main_view(); ?>

</div>